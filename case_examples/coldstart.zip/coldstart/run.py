import os
# from pathlib import Path

# output = Path(__file__).parent.joinpath("output.txt")

# result = {
# 	"result":Path(__file__).parent.stem
# }
# output.open('w').write(str(result))


output = os.path.join(os.path.dirname(__file__), "output.txt")
with open(output, "w") as f:
	f.write(os.path.basename(os.path.dirname(__file__)))